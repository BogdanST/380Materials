from TMs import *

''' How to specify delta:
        Each entry hs the form:

        'current state': { 'symbol read' : ('symbol to write', move right/left, 'next state') }

             1 for 'move right'
            -1 for 'move left'

 e.g. '1': {'0':('_', 1,'2'), ... means:
     When in state 1:
       on reading 0: write _ (blank symbol), move right, go to state 2
'''

delta = {
      '1': {'0':('_', 1,'2'),  '_':('_', 1,'R'),  'x':('x', 1,'R')}
    , '2': {'0':('x', 1,'3'),  '_':('_', 1,'A'),  'x':('x', 1,'2')}
    , '3': {'0':('0', 1,'4'),  '_':('_',-1,'5'),  'x':('x', 1,'3')}
    , '4': {'0':('x', 1,'3'),  '_':('_', 1,'R'),  'x':('x', 1,'4')}
    , '5': {'0':('0',-1,'5'),  '_':('_', 1,'2'),  'x':('x',-1,'5')}
    }

print("Enter 0 to quit")
n = int(input( "Simulate the TM on 0^" ))
while n!=0:
    TM("0"*n, delta, '1')
    n = int(input( "Simulate the TM on 0^" ))

