#################
import sys
from colorama import init, Fore, Back, Style

init()

#################

def configuration(tape, state, pos, direction):
    background = Back.RED
    #sys.stdout.write('%s %s' % (background, Back.RESET))
    tape = tape.replace('x', Back.YELLOW+Fore.RED + 'x' +Back.RESET+Fore.RESET)
    tape = tape.replace('0', Back.YELLOW+Fore.BLUE + '0' +Back.RESET+Fore.RESET)
    tape = tape.replace('_', Back.YELLOW+Fore.BLUE + ' ' +Back.RESET+Fore.RESET)
    return " "*pos+(Fore.CYAN+state+Fore.RESET)+'\n'+tape

def TM(tape, delta, qstart):
    state = qstart
    pos = 0
    halt = 3
    print( configuration(tape,'1',pos,1) )
    while state != 'A' and state != 'R':
        d = delta[ state ][ tape[pos] ]
        tape  = tape[:pos]+d[0]+tape[pos+1:]
        pos  += d[1]
        if pos>=len(tape):
            tape += "_"
            halt -= 1
        if halt==0:
            print("Giving up...")
            return
        state = d[2]
        print( configuration(tape,state,pos,d[1]) )
