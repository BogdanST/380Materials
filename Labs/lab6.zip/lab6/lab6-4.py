from TMs import *

''' How to specify delta:
        Each entry hs the form:

        'current state': { 'symbol read' : ('symbol to write', move right/left, 'next state') }

             1 for 'move right'
            -1 for 'move left'

 e.g. '1': {'0':('_', 1,'2'), ... means:
     When in state 1:
       on reading 0: write _ (blank symbol), move right, go to state 2
'''

delta = {
      'q': {'0':('0', 1,'q'),  '1':('0', 1,'p'),  '_':('_', 1,'q')}
    , 'p': {'0':('0',-1,'q'),  '1':('1', 1,'A'),  '_':('0',-1,'q')}
    }

print("Enter q to quit")
w = input( "Simulate the TM on: " )
while w!="q":
    TM(w, delta, 'q')
    w = input( "Simulate the TM on: " )
